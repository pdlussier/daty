# -*- coding: utf-8 -*-
"""Package to provide compatibility with compat scripts."""
